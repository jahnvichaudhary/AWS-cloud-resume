# AWS Cloud Resume Challenge
[![Upload Website](https://github.com/rishabkumar7/aws-cloud-resume-challenge/actions/workflows/front-end-CICD.yml/badge.svg)](https://github.com/rishabkumar7/aws-cloud-resume-challenge/actions/workflows/front-end-CICD.yml)

This is my attempt at cloud resume challenge in AWS.
What is Cloud Resume Challenge? - [The Cloud Resume Challenge](https://cloudresumechallenge.dev/) is a multiple-step resume project which helps build and demonstrate skills fundamental to pursuing a career in Cloud. The project was published by Forrest Brazeal.

## Architecture

![Architecture Diagram](/img/AWS-Architecture-Cloud-resume-challenge.png)

**Services Used**:

- S3
- AWS CloudFront
- Certificate Manager
- AWS Lambda
- Dynamo DB
- GitHub Actions
- Terraform

## [Live Demo 🔗](https://resume.rishab.cloud)

## YouTube Series

- Part 1 - [What is the Cloud Resume Challenge?](https://youtu.be/NNKzYhvqq5w)
- Part 2 - [Setting up S3 bucket and CloudFront](https://youtu.be/P5UGhdud_ss)
- Part 3 - [Setting up Dynamo DB and AWS Lambda Function](https://youtu.be/x5iTWZbOgww)
- Part 4 - [Lambda and JavaScript to get viewer counter](https://youtu.be/x6TIihJSaLA)
- Part 5 - [Setting up Git repo and CI/CD for frontend website](https://youtu.be/qFEf6iOo-4g)
- Part 6 - [Implementing Infrastructure as Code with Terraform](https://youtu.be/rzdSuiU_TQc)

 
## Author
- Twitter: [@rishabincloud](https://twitter.com/rishabincloud)
- LinkedIn: [rishabkumar7](https://linked.com/in/rishabkumar7)
  
## Stars
[![Stargazers over time](https://starchart.cc/rishabkumar7/aws-cloud-resume-challenge.svg?variant=adaptive)](https://starchart.cc/rishabkumar7/aws-cloud-resume-challenge)
